# توزيعاتي — Android MVP

تطبيق Android عربي RTL باسم **توزيعاتي**.

## البناء عبر GitHub Actions

هذا المشروع لا يحتاج إلى Gradle Wrapper لكي يعمل الـCI؛ GitHub Actions يقوم بتثبيت Gradle 8.10.2 ثم يبني:

- Debug APK للتجربة على الجوال.
- Release AAB غير موقّع، وهو مخصص لمرحلة البناء فقط وليس جاهزًا للرفع إلى Google Play قبل إعداد مفتاح الرفع والتوقيع.

### خطوات الرفع إلى GitHub

1. أنشئ Repository جديدًا باسم `tawziati-android`.
2. ارفع **محتويات هذا المجلد** إلى repository (وليس ملف ZIP نفسه).
3. افتح تبويب **Actions** في GitHub.
4. اختر **Build Tawziati Android** ثم **Run workflow**.
5. بعد نجاح البناء افتح الـworkflow ثم **Artifacts**.
6. حمّل `tawziati-debug-apk` لتثبيت نسخة التجربة على Android.

### ملاحظات مهمة

- package: `com.tawziati.app`
- target/compile SDK: 36
- البيانات داخل الواجهة الحالية تجريبية وليست بيانات سوق حية.
- لا توجد مفاتيح API أو مفاتيح توقيع داخل GitHub repository.
- قبل النشر التجاري يجب إضافة مصدر بيانات مرخّص، AdMob، سياسة الخصوصية، Data Safety، وتوقيع release/upload key.
