package com.tawziati.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int GREEN = Color.rgb(0,105,85), LIGHT = Color.rgb(246,249,248), GOLD = Color.rgb(198,158,61), TEXT=Color.rgb(24,40,36);
    LinearLayout root, content, nav; TextView title;
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s,float size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); t.setLayoutParams(new LinearLayout.LayoutParams(-1,-2)); return t; }
    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }
    TextView card(String s){ TextView t=tv(s,15,TEXT,false); t.setPadding(dp(16),dp(14),dp(16),dp(14)); t.setBackground(bg(Color.WHITE,14)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(6),0,0); t.setLayoutParams(p); return t; }
    void addGap(int h){ Space x=new Space(this); x.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); content.addView(x); }

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(0); buildShell(); showHome(); }

    void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(LIGHT); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout header=new LinearLayout(this); header.setOrientation(LinearLayout.HORIZONTAL); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(18),dp(14),dp(18),dp(14)); header.setBackgroundColor(Color.WHITE);
        title=tv("توزيعاتي",22,TEXT,true); title.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); header.addView(title,new LinearLayout.LayoutParams(0,dp(54),1));
        TextView bell=tv("🔔",22,TEXT,false); bell.setGravity(Gravity.CENTER); header.addView(bell,new LinearLayout.LayoutParams(dp(48),dp(54)));
        root.addView(header);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16),dp(12),dp(16),dp(12)); ScrollView sc=new ScrollView(this); sc.setFillViewport(true); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(4),dp(6),dp(4),dp(6)); nav.setBackgroundColor(Color.WHITE);
        addNav("الرئيسية",0); addNav("محفظتي",1); addNav("التوزيعات",2); addNav("التقويم",3); addNav("المزيد",4); root.addView(nav,new LinearLayout.LayoutParams(-1,dp(68)));
        setContentView(root);
    }
    void addNav(String label,int idx){ Button b=new Button(this); b.setText(label); b.setTextSize(11); b.setTextColor(TEXT); b.setAllCaps(false); b.setBackgroundColor(Color.TRANSPARENT); b.setOnClickListener(v->{ if(idx==0)showHome(); else if(idx==1)showPortfolio(); else if(idx==2)showDividends(); else if(idx==3)showCalendar(); else showMore();}); nav.addView(b,new LinearLayout.LayoutParams(0,-1,1)); }
    void reset(String t){ content.removeAllViews(); title.setText(t); }
    TextView heading(String s){ TextView t=tv(s,19,TEXT,true); t.setPadding(0,dp(8),0,dp(4)); content.addView(t); return t; }
    TextView primary(String s){ TextView t=tv(s,15,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setPadding(dp(14),dp(14),dp(14),dp(14)); t.setBackground(bg(GREEN,14)); t.setOnClickListener(v->Toast.makeText(this,"الميزة قيد الربط بالبيانات الحقيقية",Toast.LENGTH_SHORT).show()); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(8),0,0); t.setLayoutParams(p); content.addView(t); return t; }

    void showHome(){ reset("توزيعاتي");
        TextView hero=tv("اعرف دخلك من أسهمك\n\n12,450 ر.س  •  التوزيعات السنوية",17,Color.WHITE,true); hero.setPadding(dp(18),dp(20),dp(18),dp(20)); hero.setBackground(bg(GREEN,18)); content.addView(hero);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,dp(8),0,0);
        TextView a=stat("المتوسط الشهري","1,037 ر.س"), c=stat("أقرب توزيعة","800 ر.س"); row.addView(a,new LinearLayout.LayoutParams(0,-2,1)); Space sp=new Space(this); row.addView(sp,new LinearLayout.LayoutParams(dp(8),1)); row.addView(c,new LinearLayout.LayoutParams(0,-2,1)); content.addView(row);
        heading("أقرب توزيعة"); content.addView(card("الراجحي\n800 ر.س • 5 أكتوبر 2026\nموعد التوزيع المتوقع"));
        heading("محفظتي"); content.addView(card("الراجحي   1,000 سهم   • دخل متوقع 800 ر.س")); content.addView(card("أرامكو السعودية   1,500 سهم   • دخل متوقع 615 ر.س")); content.addView(card("موبايلي   500 سهم   • دخل متوقع 1,350 ر.س"));
        primary("📅  افتح تقويم التوزيعات"); primary("🧮  احسب راتبي من الأسهم");
    }
    TextView stat(String a,String b){ TextView t=tv(a+"\n"+b,13,TEXT,true); t.setPadding(dp(14),dp(14),dp(14),dp(14)); t.setBackground(bg(Color.WHITE,14)); return t; }
    void showPortfolio(){ reset("محفظتي");
        heading("قيمة المحفظة"); content.addView(card("132,450 ر.س\n+8,320 ر.س  (+6.7%)"));
        heading("المراكز"); content.addView(card("الراجحي\n1,000 سهم • متوسط 78.40 ر.س\nالقيمة 92,500 ر.س • العائد +17.9%")); content.addView(card("أرامكو السعودية\n1,500 سهم • متوسط 28.10 ر.س\nالقيمة 46,200 ر.س • العائد +12.7%")); content.addView(card("stc\n600 سهم • متوسط 40.20 ر.س\nالقيمة 46,200 ر.س • العائد +16.2%")); content.addView(card("المراعي\n600 سهم • متوسط 43.30 ر.س\nالقيمة 49,100 ر.س • العائد +13.7%")); primary("＋ إضافة سهم للمحفظة");
    }
    void showDividends(){ reset("توزيعاتي");
        TextView hero=tv("إجمالي التوزيعات السنوية\n8,940 ر.س",17,TEXT,true); hero.setPadding(dp(18),dp(20),dp(18),dp(20)); hero.setBackground(bg(Color.WHITE,18)); content.addView(hero);
        heading("القادمة"); content.addView(card("الراجحي   •   420 ر.س\n5 أكتوبر 2026")); content.addView(card("موبايلي   •   1,125 ر.س\n20 أكتوبر 2026")); content.addView(card("المراعي   •   730 ر.س\n28 أكتوبر 2026")); content.addView(card("أرامكو السعودية   •   2,100 ر.س\n5 نوفمبر 2026"));
        heading("هذا الشهر"); content.addView(card("إجمالي متوقع: 2,275 ر.س"));
    }
    void showCalendar(){ reset("تقويم التوزيعات");
        TextView cal=tv("أكتوبر 2026\n\nالأحد   الاثنين   الثلاثاء   الأربعاء   الخميس   الجمعة   السبت\n      1      2      3      4      5      6\n7      8      9      10     11     12     13\n14     15     16     17     18     19     20\n21     22     23     24     25     26     27\n28     29     30     31",14,TEXT,false); cal.setPadding(dp(14),dp(18),dp(14),dp(18)); cal.setBackground(bg(Color.WHITE,16)); content.addView(cal);
        heading("التوزيعات هذا الشهر"); content.addView(card("5 أكتوبر  • الراجحي • 420 ر.س")); content.addView(card("20 أكتوبر • موبايلي • 1,125 ر.س")); content.addView(card("28 أكتوبر • المراعي • 730 ر.س"));
    }
    void showMore(){ reset("المزيد");
        heading("أدواتك"); primary("🔎 البحث عن سهم"); primary("🧮 راتبي من الأسهم"); primary("📊 تحليلاتي"); primary("🔔 التنبيهات"); primary("⭐ الاشتراك Pro");
        heading("الإعدادات"); content.addView(card("الحساب\nالخصوصية\nسياسة الاستخدام\nمساعدة ودعم"));
    }
}
